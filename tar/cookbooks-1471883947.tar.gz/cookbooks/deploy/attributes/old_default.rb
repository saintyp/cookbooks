#node.default['src_filename'] = "/var/www/#{node['hostname']}.txt"
#node.default['src_filename'] = "/var/www/attributes.txt" 